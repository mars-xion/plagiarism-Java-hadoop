package org.Mazoun;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class PlagiarismCheckerGUI extends JFrame {

    private JTextArea inputTextArea;
    private JTextArea outputTextArea;
    private JButton detectButton;
    private JButton uploadButton;
    private JComboBox<String> detectionLogicComboBox;
    private JLabel percentageLabel;

    public PlagiarismCheckerGUI() {
        setTitle("Plagiarism Checker");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(800, 600));

        JPanel inputPanel = new JPanel(new BorderLayout());
        JLabel inputLabel = new JLabel("Input Text:");
        inputTextArea = new JTextArea();
        JScrollPane inputScrollPane = new JScrollPane(inputTextArea);
        inputScrollPane.setPreferredSize(new Dimension(400, 200)); // Set preferred size for input text area
        inputPanel.add(inputLabel, BorderLayout.NORTH);
        inputPanel.add(inputScrollPane, BorderLayout.CENTER);

        JPanel outputPanel = new JPanel(new BorderLayout());
        JLabel outputLabel = new JLabel("Output Text:");
        outputTextArea = new JTextArea();
        JScrollPane outputScrollPane = new JScrollPane(outputTextArea);
        outputPanel.add(outputLabel, BorderLayout.NORTH);
        outputPanel.add(outputScrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        detectButton = new JButton("Detect Plagiarism");
        detectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String inputText = inputTextArea.getText();
                String selectedDetectionLogic = (String) detectionLogicComboBox.getSelectedItem();

                // Perform comparison logic based on the selected detection logic
                double plagiarismPercentage = PlagiarismDetector.calculatePlagiarismPercentage(selectedDetectionLogic, inputText, "");
                percentageLabel.setText("Plagiarism Percentage: " + plagiarismPercentage + "%");
            }
        });
        uploadButton = new JButton("Upload File");
        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(null);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    try {
                        String fileContent = new String(Files.readAllBytes(selectedFile.toPath()));
                        inputTextArea.setText(fileContent);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        buttonPanel.add(detectButton);
        buttonPanel.add(uploadButton);

        // Detection Logic Dropdown
        String[] detectionLogics = {"Levenshtein Distance", "Cosine Similarity", "Jaccard Similarity"};
        detectionLogicComboBox = new JComboBox<>(detectionLogics);

        JPanel dropdownPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        dropdownPanel.add(new JLabel("Detection Logic:"));
        dropdownPanel.add(detectionLogicComboBox);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(outputPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        percentageLabel = new JLabel("Plagiarism Percentage: ");
        JPanel percentagePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        percentagePanel.add(percentageLabel);

        add(mainPanel, BorderLayout.CENTER);
        add(dropdownPanel, BorderLayout.NORTH);
        add(percentagePanel, BorderLayout.SOUTH);

        pack();
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new PlagiarismCheckerGUI();
            }
        });
    }
}


