package org.Mazoun;

import org.apache.commons.text.similarity.CosineSimilarity;
import org.apache.commons.text.similarity.LevenshteinDistance;

import java.util.*;

public class PlagiarismDetector {
    public static double calculatePlagiarismPercentage(String detectionLogic, String inputText, String comparisonText) {
        if (detectionLogic.equals("Levenshtein Distance")) {
            LevenshteinDistance levenshteinDistance = new LevenshteinDistance();
            int distance = levenshteinDistance.apply(inputText, comparisonText);
            int maxLength = Math.max(inputText.length(), comparisonText.length());
            double similarity = 1 - ((double) distance / maxLength);
            return similarity * 100;
        } else if (detectionLogic.equals("Cosine Similarity")) {
            Map<CharSequence, Integer> inputVector = textToVector(inputText);
            Map<CharSequence, Integer> comparisonVector = textToVector(comparisonText);

            CosineSimilarity cosineSimilarity = new CosineSimilarity();
            double similarity = cosineSimilarity.cosineSimilarity(inputVector, comparisonVector);

            return similarity * 100;
        } else if (detectionLogic.equals("Jaccard Similarity")) {
            // Perform Jaccard Similarity calculation
            double plagiarismPercentage = calculateJaccardSimilarity(inputText, comparisonText);
            return plagiarismPercentage;
        } else {
            // Invalid detection logic
            throw new IllegalArgumentException("Invalid detection logic: " + detectionLogic);
        }
    }

    private static Map<CharSequence, Integer> textToVector(String text) {
        String[] words = text.split(" ");
        Map<CharSequence, Integer> vector = new HashMap<>();

        for (String word : words) {
            vector.put(word, vector.getOrDefault(word, 0) + 1);
        }

        return vector;
    }

    private static double calculateJaccardSimilarity(String inputText, String comparisonText) {
        // Convert the input text and comparison text to sets of words
        Set<String> inputSet = new HashSet<>(Arrays.asList(inputText.split(" ")));
        Set<String> comparisonSet = new HashSet<>(Arrays.asList(comparisonText.split(" ")));

        // Calculate the size of the intersection and union of the sets
        Set<String> intersection = new HashSet<>(inputSet);
        intersection.retainAll(comparisonSet);
        Set<String> union = new HashSet<>(inputSet);
        union.addAll(comparisonSet);

        // Calculate the Jaccard similarity coefficient
        double jaccardSimilarity = (double) intersection.size() / union.size();

        // Convert the similarity coefficient to a percentage
        double plagiarismPercentage = jaccardSimilarity * 100;

        return plagiarismPercentage;
    }
}
