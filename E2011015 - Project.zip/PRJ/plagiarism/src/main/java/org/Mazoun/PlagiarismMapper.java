package org.Mazoun;

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class PlagiarismMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    private static final int NUM_SHINGLES = 3;

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString().toLowerCase();
        String[] words = line.split(" ");

        // Generate shingles and emit them as key-value pairs
        for (int i = 0; i <= words.length - NUM_SHINGLES; i++) {
            StringBuilder shingleBuilder = new StringBuilder();
            for (int j = 0; j < NUM_SHINGLES; j++) {
                shingleBuilder.append(words[i + j]).append(" ");
            }
            context.write(new Text(shingleBuilder.toString().trim()), new IntWritable(1));
        }
    }
}
